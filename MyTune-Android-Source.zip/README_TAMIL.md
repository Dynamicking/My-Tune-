# MyTune Android App (APK source project)

இந்த project Android Studio இல்லாமல் GitHub Actions மூலம் APK build செய்யத் தயாரிக்கப்பட்டது.

## உள்ள வசதிகள்
- Phone-ல் உள்ள audio files தேர்ந்தெடுத்து play செய்யும் local music player
- YouTube search-ஐ official YouTube results-க்கு திறக்கும்
- Spotify search-ஐ official Spotify web page-க்கு திறக்கும்
- Playlist, play/pause/seek, theme colours, dark/light appearance
- Android WebView wrapper; app icon/launcher label: MyTune

## முக்கியமான வரம்புகள்
- இது முதல் prototype. இந்த சூழலில் உண்மையான Android phone அல்லது cloud build-ல் install செய்து சோதிக்கப்படவில்லை.
- YouTube/Spotify பாடல்களை இந்த app-க்குள் நேரடியாக stream செய்வதில்லை; அதிகாரப்பூர்வ பக்கங்களைத் திறக்கிறது. Direct streaming-க்கு அந்த platform-களின் API, SDK, account மற்றும் policy requirements தேவை.
- இந்த source project-இல் release-signed APK இல்லை. GitHub Actions உருவாக்குவது debug APK.

## Android Studio இல்லாமல் APK உருவாக்குவது (Android phone-லிருந்தும் செய்யலாம்)
1. GitHub account-ல் புதிய **public** repository உருவாக்கவும்; உதாரணமாக `MyTune`.
2. இந்த ZIP-ஐ unzip செய்யவும்.
3. எல்லா files/folders-ஐ repository-க்கு upload செய்து commit செய்யவும். `.github/workflows/build-apk.yml` உட்பட hidden `.github` folder-ஐயும் upload செய்ய வேண்டும்.
4. Repository-ல் **Actions** tab திறக்கவும். `Build MyTune APK` workflow-ஐத் தேர்ந்தெடுத்து **Run workflow** அழுத்தவும். (முதல் push-லும் build தானாக ஓடும்.)
5. Build முடிந்ததும் workflow run-ன் கீழே **Artifacts** பகுதியில் `MyTune-debug-APK` download செய்யவும்.
6. ZIP artifact-ஐ extract செய்து `app-debug.apk`-ஐ Android phone-ல் திறந்து install செய்யவும். Android கேட்டால் அந்த browser/file manager-க்கு “Install unknown apps” அனுமதி கொடுக்கவும்.

## Build configuration
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Java 17
- minSdk 23 (Android 6.0+)
- targetSdk 35

## Privacy
App உங்கள் தேர்ந்தெடுத்த local audio file-ஐ play செய்யும்; அந்த audio-ஐ upload செய்யாது. YouTube/Spotify search திறந்தால் அந்த சேவைகளின் privacy policies பொருந்தும்.
